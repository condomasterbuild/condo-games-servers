import { useEffect, useState } from 'react';
import { ImageAdjustment, VisualSceneKey } from '../data/condoGames';

interface CondoThumbnailProps {
  title: string;
  imageUrl?: string;
  sceneKey: VisualSceneKey;
  adjustment?: ImageAdjustment;
  className?: string;
}

function ArchitecturalSceneSvg({ sceneKey }: { sceneKey: VisualSceneKey }) {
  if (sceneKey === 'skyline-atrium') {
    return (
      <svg viewBox="0 0 640 360" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id="atriumBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#080b14" />
            <stop offset="55%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#090d16" />
          </linearGradient>
          <linearGradient id="atriumGlow" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
          </linearGradient>
        </defs>
        <rect width="640" height="360" fill="url(#atriumBg)" />
        <rect x="64" y="36" width="512" height="250" fill="#060911" stroke="#1e293b" strokeWidth="1.5" />
        {/* Skyline silhouettes */}
        <rect x="92" y="128" width="44" height="158" fill="#0e1628" />
        <rect x="148" y="92" width="58" height="194" fill="#131d33" />
        <rect x="220" y="140" width="48" height="146" fill="#0d1424" />
        <rect x="284" y="72" width="64" height="214" fill="#142038" />
        <rect x="366" y="112" width="52" height="174" fill="#0f182c" />
        <rect x="432" y="84" width="62" height="202" fill="#131f36" />
        <rect x="506" y="132" width="46" height="154" fill="#0d1424" />
        {/* Warm window lights */}
        <rect x="160" y="110" width="8" height="5" fill="#fbbf24" opacity="0.65" />
        <rect x="176" y="124" width="8" height="5" fill="#60a5fa" opacity="0.55" />
        <rect x="298" y="96" width="12" height="6" fill="#60a5fa" opacity="0.7" />
        <rect x="318" y="118" width="10" height="6" fill="#fbbf24" opacity="0.6" />
        <rect x="448" y="106" width="10" height="5" fill="#34d399" opacity="0.55" />
        {/* Glass mullion grid */}
        <line x1="192" y1="36" x2="192" y2="286" stroke="#1e293b" strokeWidth="2" />
        <line x1="320" y1="36" x2="320" y2="286" stroke="#1e293b" strokeWidth="2" />
        <line x1="448" y1="36" x2="448" y2="286" stroke="#1e293b" strokeWidth="2" />
        <line x1="64" y1="168" x2="576" y2="168" stroke="#1e293b" strokeWidth="1.5" />
        {/* Mezzanine & Lounge Floor */}
        <polygon points="0,286 640,286 640,360 0,360" fill="#0a0e17" />
        <rect x="160" y="254" width="320" height="32" rx="3" fill="#131926" stroke="#243044" strokeWidth="1" />
        <rect x="255" y="274" width="130" height="6" rx="2" fill="url(#atriumGlow)" />
        <circle cx="320" cy="48" r="3" fill="#fbbf24" opacity="0.85" />
        <circle cx="215" cy="48" r="2.5" fill="#fbbf24" opacity="0.65" />
        <circle cx="425" cy="48" r="2.5" fill="#fbbf24" opacity="0.65" />
      </svg>
    );
  }

  if (sceneKey === 'rainy-loft') {
    return (
      <svg viewBox="0 0 640 360" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id="loftBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#090a12" />
            <stop offset="60%" stopColor="#121626" />
            <stop offset="100%" stopColor="#07090f" />
          </linearGradient>
        </defs>
        <rect width="640" height="360" fill="url(#loftBg)" />
        {/* Large industrial arched/grid window */}
        <rect x="88" y="32" width="464" height="236" fill="#070b14" stroke="#263147" strokeWidth="2" />
        <line x1="204" y1="32" x2="204" y2="268" stroke="#1e2738" strokeWidth="2" />
        <line x1="320" y1="32" x2="320" y2="268" stroke="#1e2738" strokeWidth="2" />
        <line x1="436" y1="32" x2="436" y2="268" stroke="#1e2738" strokeWidth="2" />
        <line x1="88" y1="112" x2="552" y2="112" stroke="#1e2738" strokeWidth="1.5" />
        <line x1="88" y1="190" x2="552" y2="190" stroke="#1e2738" strokeWidth="1.5" />
        {/* Elevated transit track & train glow */}
        <rect x="88" y="206" width="464" height="10" fill="#161f33" />
        <rect x="210" y="196" width="160" height="10" rx="2" fill="#2563eb" opacity="0.55" />
        <rect x="220" y="198" width="24" height="4" fill="#93c5fd" opacity="0.9" />
        <rect x="252" y="198" width="24" height="4" fill="#93c5fd" opacity="0.9" />
        <rect x="284" y="198" width="24" height="4" fill="#93c5fd" opacity="0.9" />
        <rect x="316" y="198" width="24" height="4" fill="#93c5fd" opacity="0.9" />
        {/* Loft floor & synth desk */}
        <rect x="0" y="268" width="640" height="92" fill="#0b0e17" />
        <rect x="130" y="252" width="120" height="34" rx="2" fill="#171d2c" stroke="#28324a" />
        <rect x="148" y="230" width="38" height="22" rx="2" fill="#0f172a" stroke="#3b82f6" strokeOpacity="0.6" />
        <rect x="370" y="246" width="140" height="42" rx="3" fill="#141a26" stroke="#252f42" />
        <circle cx="486" cy="214" r="14" fill="#fbbf24" opacity="0.16" />
        <circle cx="486" cy="214" r="4" fill="#fbbf24" opacity="0.85" />
      </svg>
    );
  }

  if (sceneKey === 'zen-pavilion') {
    return (
      <svg viewBox="0 0 640 360" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id="zenSky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#070a10" />
            <stop offset="100%" stopColor="#101824" />
          </linearGradient>
        </defs>
        <rect width="640" height="360" fill="url(#zenSky)" />
        {/* Moon */}
        <circle cx="488" cy="78" r="24" fill="#e2e8f0" opacity="0.16" />
        <circle cx="488" cy="78" r="16" fill="#f8fafc" opacity="0.72" />
        {/* Pavilion roof */}
        <polygon points="100,118 320,66 540,118 520,128 320,82 120,128" fill="#151b26" stroke="#293448" />
        {/* Timber columns & shoji screens */}
        <rect x="148" y="124" width="344" height="148" fill="#0d131d" stroke="#253042" />
        <rect x="196" y="142" width="108" height="114" fill="#f59e0b" opacity="0.11" stroke="#334155" />
        <rect x="336" y="142" width="108" height="114" fill="#34d399" opacity="0.08" stroke="#334155" />
        <line x1="250" y1="142" x2="250" y2="256" stroke="#263244" />
        <line x1="390" y1="142" x2="390" y2="256" stroke="#263244" />
        {/* Reflection Pond */}
        <rect x="0" y="272" width="640" height="88" fill="#080d16" />
        <ellipse cx="320" cy="316" rx="220" ry="20" fill="#0e1b2c" stroke="#1e3a5f" strokeOpacity="0.4" />
        <circle cx="176" cy="252" r="5" fill="#fbbf24" opacity="0.8" />
        <circle cx="464" cy="252" r="5" fill="#fbbf24" opacity="0.8" />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 640 360" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="orbitalBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#050811" />
          <stop offset="60%" stopColor="#0b152b" />
          <stop offset="100%" stopColor="#070a12" />
        </linearGradient>
      </defs>
      <rect width="640" height="360" fill="url(#orbitalBg)" />
      {/* Stars */}
      <circle cx="96" cy="64" r="1.5" fill="#cbd5e1" opacity="0.6" />
      <circle cx="188" cy="44" r="1.2" fill="#93c5fd" opacity="0.7" />
      <circle cx="412" cy="56" r="1.8" fill="#e2e8f0" opacity="0.5" />
      <circle cx="524" cy="88" r="1.5" fill="#60a5fa" opacity="0.6" />
      {/* Curved observatory dome window */}
      <path d="M 88 264 A 232 190 0 0 1 552 264 Z" fill="#081021" stroke="#1e3a5f" strokeWidth="2" />
      <path d="M 180 264 A 140 120 0 0 1 460 264" fill="none" stroke="#1e293b" strokeWidth="1.5" />
      {/* Cloud horizon glow */}
      <ellipse cx="320" cy="264" rx="220" ry="26" fill="#2563eb" opacity="0.18" />
      {/* Deck */}
      <rect x="0" y="264" width="640" height="96" fill="#090d16" />
      <rect x="190" y="256" width="260" height="24" rx="4" fill="#131c2e" stroke="#26354d" />
      <line x1="210" y1="276" x2="430" y2="276" stroke="#3b82f6" strokeWidth="2" strokeOpacity="0.6" />
    </svg>
  );
}

export function CondoThumbnail({
  title,
  imageUrl,
  sceneKey,
  adjustment,
  className = '',
}: CondoThumbnailProps) {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [imageUrl]);

  const filterStyle = adjustment
    ? `brightness(${adjustment.brightness}%) contrast(${adjustment.contrast}%) saturate(${adjustment.saturate}%)`
    : undefined;

  const positionClass =
    adjustment?.objectPosition === 'top'
      ? 'object-top'
      : adjustment?.objectPosition === 'bottom'
      ? 'object-bottom'
      : 'object-center';

  return (
    <div className={`relative aspect-video w-full overflow-hidden bg-[#080a0f] ${className}`}>
      {imageUrl && !hasError ? (
        <img
          src={imageUrl}
          alt={`${title} virtual condo environment`}
          referrerPolicy="no-referrer"
          onError={() => setHasError(true)}
          style={filterStyle ? { filter: filterStyle } : undefined}
          className={`h-full w-full object-cover ${positionClass} transition-transform duration-300 ease-out group-hover:scale-[1.03]`}
        />
      ) : (
        <div
          style={filterStyle ? { filter: filterStyle } : undefined}
          className="h-full w-full transition-transform duration-300 ease-out group-hover:scale-[1.03]"
        >
          <ArchitecturalSceneSvg sceneKey={sceneKey} />
        </div>
      )}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#050608]/80 via-[#050608]/15 to-transparent"
      />
    </div>
  );
}
