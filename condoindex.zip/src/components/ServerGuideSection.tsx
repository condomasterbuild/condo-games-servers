interface ServerGuideSectionProps {
  onBrowseClick: () => void;
  onOpenSubmit: () => void;
}

const GUIDE_STEPS = [
  {
    index: '01.',
    title: 'Browse Live Capacity',
    body: 'Check real-time player counts and server pings before hopping in so you never land in an empty room.',
  },
  {
    index: '02.',
    title: 'Join Any Open Instance',
    body: 'Pick a regional server that fits your squad size, copy the share link, and launch straight into the lounge.',
  },
  {
    index: '03.',
    title: 'Support Small Creators',
    body: 'Every like pushes independent condo builders higher in the directory and helps keep public rooms active.',
  },
];

export function ServerGuideSection({ onBrowseClick, onOpenSubmit }: ServerGuideSectionProps) {
  return (
    <>
      <section id="how-it-works" className="border-t border-white/[0.06] bg-transparent">
        <div className="mx-auto max-w-7xl px-6 py-16 lg:py-20">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">
                How CondoIndex Works
              </h2>
              <p className="mt-2 max-w-xl text-sm text-slate-400">
                Built to cut out broken links and help players find active social condos in seconds.
              </p>
            </div>
            <button
              type="button"
              onClick={onBrowseClick}
              className="self-start rounded-lg bg-[#1E62EC] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
            >
              Explore Live Worlds
            </button>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-8 border-t border-white/[0.06] pt-10 md:grid-cols-3">
            {GUIDE_STEPS.map((step) => (
              <div key={step.index}>
                <span className="font-mono text-xs font-semibold text-[#4B83F2]">{step.index}</span>
                <h3 className="font-display mt-2 text-lg font-bold text-white">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-white/[0.06] bg-transparent">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-6 py-8 sm:flex-row sm:items-center">
          <div>
            <span className="font-display text-sm font-bold text-white">CondoIndex</span>
            <p className="mt-1 text-xs text-slate-500">
              Curated virtual condo and social hangout directory for independent creators.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-400">
            <button
              type="button"
              onClick={onBrowseClick}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Directory
            </button>
            <a href="#creators" className="hover:text-white transition-colors">
              Creators
            </a>
            <button
              type="button"
              onClick={onOpenSubmit}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Submit a World
            </button>
          </div>
        </div>
      </footer>
    </>
  );
}
