import { CondoGame, formatCompactNumber } from '../data/condoGames';

interface CreatorsSectionProps {
  games: CondoGame[];
  onFilterByCreator: (creatorName: string) => void;
  onOpenSubmit: () => void;
}

export function CreatorsSection({
  games,
  onFilterByCreator,
  onOpenSubmit,
}: CreatorsSectionProps) {
  // Aggregate top creators from live games
  const creatorMap = new Map<
    string,
    {
      name: string;
      handle: string;
      totalVisits: number;
      totalLikes: number;
      playingNow: number;
      worldCount: number;
      flagshipTitle: string;
    }
  >();

  for (const game of games) {
    const existing = creatorMap.get(game.creator);
    if (!existing) {
      creatorMap.set(game.creator, {
        name: game.creator,
        handle: game.creatorHandle,
        totalVisits: game.visits,
        totalLikes: game.likes,
        playingNow: game.playingNow,
        worldCount: 1,
        flagshipTitle: game.title,
      });
    } else {
      existing.totalVisits += game.visits;
      existing.totalLikes += game.likes;
      existing.playingNow += game.playingNow;
      existing.worldCount += 1;
    }
  }

  const topCreators = Array.from(creatorMap.values())
    .sort((a, b) => b.totalLikes - a.totalLikes)
    .slice(0, 4);

  return (
    <section id="creators" className="border-t border-white/[0.06] bg-transparent">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:py-20">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Independent Creators
            </h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-slate-400">
              Every condo in the index is built and hosted by small creator teams. Filter by studio
              or list your own build.
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenSubmit}
            className="self-start rounded-lg border border-white/[0.1] bg-white/[0.05] px-4 py-2.5 text-xs font-semibold text-white hover:bg-white/[0.1] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            Submit Your Condo
          </button>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          {topCreators.map((creator, idx) => (
            <div
              key={creator.name}
              className="flex flex-col justify-between rounded-xl border border-white/[0.07] bg-[#0B0D13] p-5"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-mono tabular-nums">0{idx + 1}</span>
                  <span>{creator.handle}</span>
                </div>
                <h3 className="font-display mt-3 text-lg font-bold text-white">{creator.name}</h3>
                <p className="mt-1 text-xs text-slate-400 truncate">
                  Flagship: {creator.flagshipTitle}
                </p>

                <div className="mt-4 grid grid-cols-2 gap-3 border-t border-white/[0.06] pt-4">
                  <div>
                    <div className="font-mono text-sm font-semibold text-[#FBBF24] tabular-nums">
                      {formatCompactNumber(creator.totalLikes)}
                    </div>
                    <div className="text-[11px] text-slate-500">Likes</div>
                  </div>
                  <div>
                    <div className="font-mono text-sm font-semibold text-[#4B83F2] tabular-nums">
                      {formatCompactNumber(creator.totalVisits)}
                    </div>
                    <div className="text-[11px] text-slate-500">Visits</div>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onFilterByCreator(creator.name)}
                className="mt-5 w-full rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-xs font-medium text-slate-200 hover:bg-white/[0.08] hover:text-white transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                Filter Worlds ({creator.worldCount})
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
