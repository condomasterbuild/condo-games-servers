import { ChangeEvent, FormEvent, useEffect, useRef, useState } from 'react';
import { Upload, X } from 'lucide-react';
import { CondoCategory, CondoGame, isSafeHttpUrl, VisualSceneKey } from '../data/condoGames';

interface SubmitCondoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitCondo: (newGame: CondoGame) => void;
}

const CATEGORIES: CondoCategory[] = ['Penthouse', 'Rooftop', 'Arcade', 'Chill & Scenic'];
const SCENES: { key: VisualSceneKey; label: string }[] = [
  { key: 'skyline-atrium', label: 'Skyline Glass Atrium' },
  { key: 'rainy-loft', label: 'Rainy Neon Loft' },
  { key: 'zen-pavilion', label: 'Zen Cedar Pavilion' },
  { key: 'orbital-suite', label: 'Orbital Sky-Suite' },
];

export function SubmitCondoModal({ isOpen, onClose, onSubmitCondo }: SubmitCondoModalProps) {
  const [title, setTitle] = useState('');
  const [creator, setCreator] = useState('');
  const [category, setCategory] = useState<CondoCategory>('Penthouse');
  const [sceneKey, setSceneKey] = useState<VisualSceneKey>('skyline-atrium');
  const [maxPlayers, setMaxPlayers] = useState(24);
  const [imageUrl, setImageUrl] = useState('');
  const [joinUrl, setJoinUrl] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleImageFile = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    const isGif =
      file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') return;
      if (isGif) {
        setImageUrl(reader.result);
        return;
      }
      const img = new Image();
      img.onload = () => {
        const maxW = 1280;
        const scale = img.width > maxW ? maxW / img.width : 1;
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          setImageUrl(canvas.toDataURL('image/jpeg', 0.86));
        } else {
          setImageUrl(reader.result as string);
        }
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedTitle = title.trim();
    const trimmedCreator = creator.trim();
    const trimmedDesc = description.trim();

    if (trimmedTitle.length < 3) {
      setError('Please enter a world title with at least 3 characters.');
      return;
    }
    if (trimmedCreator.length < 2) {
      setError('Please enter your creator or studio name.');
      return;
    }
    if (trimmedDesc.length < 15) {
      setError('Please add a brief description (at least 15 characters) so players know the vibe.');
      return;
    }
    if (joinUrl.trim().length > 0 && !isSafeHttpUrl(joinUrl)) {
      setError('Join Room Link must start with https:// or http://');
      return;
    }

    const slug = trimmedTitle
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    const handle = `@${trimmedCreator.toLowerCase().replace(/[^a-z0-9]/g, '') || 'creator'}`;
    const today = new Date().toISOString().slice(0, 10);

    const newCondo: CondoGame = {
      id: `${slug}-${Date.now()}`,
      title: trimmedTitle,
      creator: trimmedCreator,
      creatorHandle: handle,
      category,
      description: trimmedDesc,
      imageUrl: imageUrl.trim() || undefined,
      sceneKey,
      visits: 1,
      playingNow: 1,
      likes: 1,
      maxPlayers,
      updatedAt: today,
      features: ['Custom Lobby', 'Spatial Voice', 'Creator Hosted'],
      servers: [
        {
          id: `srv-${Date.now()}-1`,
          name: 'Launch Instance 01',
          region: 'US East',
          pingMs: 26,
          players: 1,
          maxPlayers,
          joinUrl: joinUrl.trim() || undefined,
        },
      ],
    };

    onSubmitCondo(newCondo);
    setTitle('');
    setCreator('');
    setImageUrl('');
    setJoinUrl('');
    setDescription('');
    setError('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="submit-condo-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-white/[0.1] bg-[#0B0D13] p-6 shadow-2xl sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="submit-condo-title" className="font-display text-xl font-bold text-white">
              List Your Condo World
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Publish an indie hangout world directly to the live directory.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close submission modal"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.04] text-slate-300 hover:bg-white/[0.1] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          {error && (
            <div
              role="alert"
              className="rounded-lg border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-xs text-red-300"
            >
              {error}
            </div>
          )}

          <div>
            <label htmlFor="condo-title" className="block text-xs font-medium text-slate-300">
              World Title
            </label>
            <input
              id="condo-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Velvet Sky Loft"
              className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="condo-creator" className="block text-xs font-medium text-slate-300">
                Creator / Studio
              </label>
              <input
                id="condo-creator"
                type="text"
                value={creator}
                onChange={(e) => setCreator(e.target.value)}
                placeholder="e.g. Lumen Indie"
                className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="condo-category" className="block text-xs font-medium text-slate-300">
                Category
              </label>
              <select
                id="condo-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as CondoCategory)}
                className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="condo-scene" className="block text-xs font-medium text-slate-300">
                Architectural Style
              </label>
              <select
                id="condo-scene"
                value={sceneKey}
                onChange={(e) => setSceneKey(e.target.value as VisualSceneKey)}
                className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
              >
                {SCENES.map((s) => (
                  <option key={s.key} value={s.key}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="condo-capacity" className="block text-xs font-medium text-slate-300">
                Max Players per Room
              </label>
              <input
                id="condo-capacity"
                type="number"
                min={4}
                max={100}
                value={maxPlayers}
                onChange={(e) => setMaxPlayers(Number(e.target.value) || 16)}
                className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white tabular-nums focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="condo-image-url" className="block text-xs font-medium text-slate-300">
                Cover Image (optional)
              </label>
              {imageUrl && (
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
                >
                  Clear Image
                </button>
              )}
            </div>
            <div className="mt-1.5 flex items-center gap-2">
              <input
                id="condo-image-url"
                type="text"
                value={imageUrl.startsWith('data:') ? '' : imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder={
                  imageUrl.startsWith('data:')
                    ? 'Uploaded custom image ready'
                    : 'Paste image URL or upload file'
                }
                className="w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageFile}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] bg-white/[0.05] px-3 py-2.5 text-xs font-medium text-white hover:bg-white/[0.1] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5" />
                <span>Upload</span>
              </button>
            </div>
          </div>

          <div>
            <label htmlFor="condo-join-url" className="block text-xs font-medium text-slate-300">
              Join Room Link (optional)
            </label>
            <input
              id="condo-join-url"
              type="url"
              value={joinUrl}
              onChange={(e) => setJoinUrl(e.target.value)}
              placeholder="https://your-game-link.com/room"
              className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 font-mono text-xs text-blue-300 placeholder:text-slate-600 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="condo-desc" className="block text-xs font-medium text-slate-300">
              World Description
            </label>
            <textarea
              id="condo-desc"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the atmosphere, music system, mini-games, or hangout spots..."
              className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-white/[0.08] px-4 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-[#1E62EC] px-5 py-2 text-xs font-semibold text-white hover:bg-[#2563EB] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
            >
              Publish to Directory
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
