interface NavbarProps {
  onOpenSubmit: () => void;
  onBrowseClick: () => void;
}

export function Navbar({ onOpenSubmit, onBrowseClick }: NavbarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-white/[0.06] bg-[#050608]/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-6 py-4">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="#top"
          className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
        >
          CondoIndex
        </a>

        {/* Zone 2: Clean single-line navigation links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400">
          <a
            href="#directory"
            onClick={(e) => {
              e.preventDefault();
              onBrowseClick();
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
          >
            Directory
          </a>
          <a
            href="#creators"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
          >
            Creators
          </a>
          <a
            href="#how-it-works"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
          >
            Server Guide
          </a>
          <button
            type="button"
            onClick={onOpenSubmit}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
          >
            Submit World
          </button>
        </nav>
      </div>
    </header>
  );
}
