import { FormEvent, useState } from 'react';
import { ArrowRight, Check, Heart, Image, Pencil, RotateCcw, X } from 'lucide-react';
import { ALLOW_PUBLIC_EDITING, CondoGame, formatCompactNumber } from '../data/condoGames';
import { CondoThumbnail } from './CondoThumbnail';
import { BackgroundSettings, GRADIENT_PRESETS } from './EditBackgroundModal';

export interface HeroCopy {
  headline: string;
  subtitle: string;
}

export const DEFAULT_HERO_COPY: HeroCopy = {
  headline: 'Find Your\nPerfect Condo,\nFaster.',
  subtitle:
    "For players who want to discover virtual condo games to play. Don't forget to leave a like and support our small creators!",
};

interface HeroSectionProps {
  games: CondoGame[];
  likedIds: Set<string>;
  heroCopy: HeroCopy;
  backgroundSettings: BackgroundSettings;
  onSaveHeroCopy: (copy: HeroCopy) => void;
  onOpenBackgroundEditor: () => void;
  onBrowseClick: () => void;
  onSelectGame: (game: CondoGame) => void;
  onToggleLike: (id: string) => void;
  onEditWorld: (game: CondoGame) => void;
}

export function HeroSection({
  games,
  likedIds,
  heroCopy,
  backgroundSettings,
  onSaveHeroCopy,
  onOpenBackgroundEditor,
  onBrowseClick,
  onSelectGame,
  onToggleLike,
  onEditWorld,
}: HeroSectionProps) {
  const featuredGames = games.filter((g) => g.featured).slice(0, 3);
  const spotlightPool = featuredGames.length > 0 ? featuredGames : games.slice(0, 3);
  const [spotlightIndex, setSpotlightIndex] = useState(0);
  const [isEditingHero, setIsEditingHero] = useState(false);
  const [draftHeadline, setDraftHeadline] = useState(heroCopy.headline);
  const [draftSubtitle, setDraftSubtitle] = useState(heroCopy.subtitle);

  const activeSpotlight = spotlightPool[spotlightIndex % spotlightPool.length] || games[0];

  const totalVisits = games.reduce((acc, g) => acc + g.visits, 0);
  const totalPlaying = games.reduce((acc, g) => acc + g.playingNow, 0);
  const totalLikes = games.reduce((acc, g) => acc + g.likes, 0);
  const gamesLive = games.length;

  const isLiked = activeSpotlight ? likedIds.has(activeSpotlight.id) : false;

  const openHeroEditor = () => {
    setDraftHeadline(heroCopy.headline);
    setDraftSubtitle(heroCopy.subtitle);
    setIsEditingHero(true);
  };

  const handleSaveHero = (e: FormEvent) => {
    e.preventDefault();
    onSaveHeroCopy({
      headline: draftHeadline.trim() || DEFAULT_HERO_COPY.headline,
      subtitle: draftSubtitle.trim() || DEFAULT_HERO_COPY.subtitle,
    });
    setIsEditingHero(false);
  };

  const handleResetHero = () => {
    setDraftHeadline(DEFAULT_HERO_COPY.headline);
    setDraftSubtitle(DEFAULT_HERO_COPY.subtitle);
    onSaveHeroCopy(DEFAULT_HERO_COPY);
    setIsEditingHero(false);
  };

  const headlineLines = heroCopy.headline.split('\n');
  const applyHeroBg = backgroundSettings.scope === 'hero';

  return (
    <section
      id="top"
      className="relative overflow-hidden border-b border-white/[0.06] bg-transparent"
    >
      {/* Hero-scoped Custom Background */}
      {applyHeroBg && (
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
          {backgroundSettings.mode === 'solid' && (
            <div
              className="absolute inset-0"
              style={{ backgroundColor: backgroundSettings.solidColor }}
            />
          )}
          {backgroundSettings.mode === 'gradient' && (
            <div
              className="absolute inset-0"
              style={{ background: GRADIENT_PRESETS[backgroundSettings.gradientPreset].css }}
            />
          )}
          {backgroundSettings.mode === 'image' && backgroundSettings.imageUrl && (
            <>
              <img
                src={backgroundSettings.imageUrl}
                alt=""
                referrerPolicy="no-referrer"
                className="absolute inset-0 h-full w-full object-cover"
                style={{
                  filter:
                    backgroundSettings.blurPx > 0
                      ? `blur(${backgroundSettings.blurPx}px)`
                      : undefined,
                  transform: backgroundSettings.blurPx > 0 ? 'scale(1.06)' : undefined,
                }}
              />
              <div
                className="absolute inset-0 bg-[#050608]"
                style={{ opacity: backgroundSettings.overlayOpacity / 100 }}
              />
            </>
          )}
        </div>
      )}

      {/* Subtle top atmospheric cobalt wash */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 right-1/4 h-[420px] w-[520px] rounded-full bg-blue-600/[0.08] blur-[120px]"
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 py-14 lg:py-24">
        {ALLOW_PUBLIC_EDITING && (
          <div className="mb-6 flex justify-end">
            <button
              type="button"
              onClick={onOpenBackgroundEditor}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.1] bg-black/45 px-3 py-1.5 text-xs font-medium text-slate-300 backdrop-blur-sm hover:border-white/[0.2] hover:text-white transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            >
              <Image className="h-3.5 w-3.5" />
              <span>Edit Background</span>
            </button>
          </div>
        )}
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-14">
          {/* Left Column: Featured Condo Spotlight (Desktop order 1, Mobile order 2) */}
          <div className="order-2 lg:order-1 lg:col-span-6">
            {activeSpotlight && (
              <div className="group overflow-hidden rounded-xl border border-white/[0.08] bg-[#0B0D13]">
                <div className="relative">
                  <CondoThumbnail
                    title={activeSpotlight.title}
                    imageUrl={activeSpotlight.imageUrl}
                    sceneKey={activeSpotlight.sceneKey}
                    adjustment={activeSpotlight.imageAdjustment}
                  />
                  {ALLOW_PUBLIC_EDITING && (
                    <button
                      type="button"
                      onClick={() => onEditWorld(activeSpotlight)}
                      aria-label={`Edit ${activeSpotlight.title}`}
                      className="absolute right-3.5 top-3.5 inline-flex items-center gap-1.5 rounded-lg border border-white/[0.14] bg-black/70 px-2.5 py-1.5 text-xs font-medium text-slate-200 backdrop-blur-sm hover:bg-black hover:text-white transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      <span>Edit</span>
                    </button>
                  )}
                  {/* Bottom-left world caption over measured scrim */}
                  <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5">
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-slate-300">
                        Featured World · {activeSpotlight.category}
                      </p>
                      <h2 className="font-display mt-1 truncate text-xl font-bold tracking-tight text-white">
                        {activeSpotlight.title}
                      </h2>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="font-mono text-sm font-semibold text-emerald-400 tabular-nums">
                        {activeSpotlight.playingNow.toLocaleString()} playing
                      </p>
                      <p className="text-xs text-slate-400">by {activeSpotlight.creator}</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/[0.06] px-5 py-4">
                  {/* Spotlight Switcher */}
                  <div className="flex items-center gap-1.5" role="tablist" aria-label="Featured condos">
                    {spotlightPool.map((item, idx) => {
                      const active = idx === spotlightIndex % spotlightPool.length;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          role="tab"
                          aria-selected={active}
                          onClick={() => setSpotlightIndex(idx)}
                          className={`rounded-md px-2.5 py-1.5 font-mono text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                            active
                              ? 'bg-white/[0.12] text-white'
                              : 'text-slate-400 hover:bg-white/[0.06] hover:text-slate-200'
                          }`}
                        >
                          0{idx + 1}
                        </button>
                      );
                    })}
                  </div>

                  {/* Quick Actions */}
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => onToggleLike(activeSpotlight.id)}
                      aria-pressed={isLiked}
                      className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                        isLiked
                          ? 'border-amber-400/40 bg-amber-400/10 text-amber-300'
                          : 'border-white/[0.08] bg-white/[0.03] text-slate-300 hover:bg-white/[0.08] hover:text-white'
                      }`}
                    >
                      <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-amber-300 text-amber-300' : ''}`} />
                      <span className="tabular-nums">{formatCompactNumber(activeSpotlight.likes)}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onSelectGame(activeSpotlight)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-white/[0.08] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-white/[0.14] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                    >
                      <span>Inspect Servers</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Iconic Hero Stack from Reference Screenshot (Desktop order 2, Mobile order 1) */}
          <div className="order-1 lg:order-2 lg:col-span-6 lg:pl-4">
            <div className="mx-auto max-w-[460px] lg:mx-0">
              {isEditingHero ? (
                <form
                  onSubmit={handleSaveHero}
                  className="rounded-xl border border-white/[0.12] bg-[#0B0D13] p-4 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200">
                      Edit Hero Title & Description
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsEditingHero(false)}
                      aria-label="Cancel hero text edit"
                      className="rounded p-1 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  <div>
                    <label htmlFor="hero-headline-input" className="block text-[11px] text-slate-400">
                      Hero Title (use Enter for line breaks)
                    </label>
                    <textarea
                      id="hero-headline-input"
                      rows={3}
                      value={draftHeadline}
                      onChange={(e) => setDraftHeadline(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3 py-2 font-display text-base font-bold text-white focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label htmlFor="hero-subtitle-input" className="block text-[11px] text-slate-400">
                      Hero Description
                    </label>
                    <textarea
                      id="hero-subtitle-input"
                      rows={3}
                      value={draftSubtitle}
                      onChange={(e) => setDraftSubtitle(e.target.value)}
                      className="mt-1 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3 py-2 text-sm text-slate-200 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleResetHero}
                      className="inline-flex items-center gap-1 rounded-lg border border-white/[0.08] px-2.5 py-1.5 text-xs text-slate-300 hover:bg-white/[0.06] cursor-pointer"
                    >
                      <RotateCcw className="h-3 w-3" />
                      <span>Reset</span>
                    </button>
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#1E62EC] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#2563EB] cursor-pointer"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Save Text</span>
                    </button>
                  </div>
                </form>
              ) : (
                <div className="group/hero relative">
                  <h1 className="font-display text-[clamp(2.5rem,4.5vw,3.5rem)] font-extrabold leading-[1.06] tracking-[-0.03em] text-white [text-wrap:balance]">
                    {headlineLines.map((line, i) => (
                      <span key={i}>
                        {line}
                        {i < headlineLines.length - 1 && <br />}
                      </span>
                    ))}
                  </h1>

                  <p className="mt-4 max-w-md text-[15px] leading-relaxed text-slate-400">
                    {heroCopy.subtitle}
                  </p>

                  {ALLOW_PUBLIC_EDITING && (
                    <button
                      type="button"
                      onClick={openHeroEditor}
                      aria-label="Edit hero title and description"
                      className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 opacity-90 sm:opacity-0 sm:group-hover/hero:opacity-100 focus-visible:opacity-100 hover:text-slate-200 transition-opacity cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
                    >
                      <Pencil className="h-3 w-3" />
                      <span>Edit hero text</span>
                    </button>
                  )}
                </div>
              )}

              <button
                type="button"
                onClick={onBrowseClick}
                className="cta-blue-glow mt-5 flex w-full items-center justify-center rounded-xl bg-[#1E62EC] px-6 py-4 font-display text-[15px] font-bold text-white transition-all duration-150 hover:bg-[#2563EB] active:scale-[0.99] whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#050608]"
              >
                Browse the games
              </button>

              {/* 2x2 Divided Live Metrics Card */}
              <div className="mt-6 grid grid-cols-2 overflow-hidden rounded-xl border border-white/[0.06] bg-[#0B0D13]">
                {/* Top-Left: Total Visits */}
                <div className="border-b border-r border-white/[0.06] px-6 py-6 text-center">
                  <div className="font-display text-[28px] font-extrabold leading-none tracking-tight text-[#4B83F2] tabular-nums">
                    {formatCompactNumber(totalVisits)}
                  </div>
                  <div className="mt-2 text-[11px] font-medium tracking-[0.06em] text-slate-400">
                    TOTAL VISITS
                  </div>
                </div>

                {/* Top-Right: Playing Now */}
                <div className="border-b border-white/[0.06] px-6 py-6 text-center">
                  <div className="font-display text-[28px] font-extrabold leading-none tracking-tight text-[#34D399] tabular-nums">
                    {formatCompactNumber(totalPlaying)}
                  </div>
                  <div className="mt-2 text-[11px] font-medium tracking-[0.06em] text-slate-400">
                    PLAYING NOW
                  </div>
                </div>

                {/* Bottom-Left: Total Likes */}
                <div className="border-r border-white/[0.06] px-6 py-6 text-center">
                  <div className="font-display text-[28px] font-extrabold leading-none tracking-tight text-[#FBBF24] tabular-nums">
                    {formatCompactNumber(totalLikes)}
                  </div>
                  <div className="mt-2 text-[11px] font-medium tracking-[0.06em] text-slate-400">
                    TOTAL LIKES
                  </div>
                </div>

                {/* Bottom-Right: Games Live */}
                <div className="px-6 py-6 text-center">
                  <div className="font-display text-[28px] font-extrabold leading-none tracking-tight text-white tabular-nums">
                    {gamesLive}
                  </div>
                  <div className="mt-2 text-[11px] font-medium tracking-[0.06em] text-slate-400">
                    GAMES LIVE
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
