import { useEffect, useState } from 'react';
import { Check, Copy, ExternalLink, Heart, Pencil, Play, X } from 'lucide-react';
import {
  ALLOW_PUBLIC_EDITING,
  CondoGame,
  CondoServer,
  formatCompactNumber,
  isSafeHttpUrl,
} from '../data/condoGames';
import { CondoThumbnail } from './CondoThumbnail';

interface GameDetailModalProps {
  game: CondoGame | null;
  isLiked: boolean;
  joinedServerId: string | null;
  onClose: () => void;
  onToggleLike: (id: string) => void;
  onEditWorld: (game: CondoGame) => void;
  onJoinServer: (gameId: string, serverId: string) => void;
  onLeaveServer: () => void;
}

export function GameDetailModal({
  game,
  isLiked,
  joinedServerId,
  onClose,
  onToggleLike,
  onEditWorld,
  onJoinServer,
  onLeaveServer,
}: GameDetailModalProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!game) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [game, onClose]);

  useEffect(() => {
    setCopied(false);
  }, [game?.id]);

  if (!game) return null;

  const handleCopyLink = () => {
    const url = `${window.location.origin}/#world-${game.id}`;
    navigator.clipboard?.writeText(url).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-world-title"
      onClick={onClose}
    >
      <div
        className="relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-white/[0.1] bg-[#0B0D13] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Hero Image */}
        <div className="relative">
          <CondoThumbnail
            title={game.title}
            imageUrl={game.imageUrl}
            sceneKey={game.sceneKey}
            adjustment={game.imageAdjustment}
          />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close world details"
            className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-lg border border-white/[0.12] bg-black/70 text-slate-200 hover:bg-black hover:text-white transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-6 sm:p-8">
          {/* Header & Actions */}
          <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                <span className="font-medium text-slate-200">{game.category}</span>
                <span aria-hidden="true">·</span>
                <span>by {game.creator} ({game.creatorHandle})</span>
                <span aria-hidden="true">·</span>
                <span>Updated {game.updatedAt}</span>
              </div>

              <h2
                id="modal-world-title"
                className="font-display mt-2 text-2xl font-bold tracking-tight text-white sm:text-3xl"
              >
                {game.title}
              </h2>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              {ALLOW_PUBLIC_EDITING && (
                <button
                  type="button"
                  onClick={() => onEditWorld(game)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.1] bg-white/[0.04] px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-white/[0.1] transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                >
                  <Pencil className="h-3.5 w-3.5" />
                  <span>Edit</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.1] bg-white/[0.04] px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-white/[0.1] transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied' : 'Share'}</span>
              </button>

              <button
                type="button"
                onClick={() => onToggleLike(game.id)}
                aria-pressed={isLiked}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isLiked
                    ? 'border-amber-400/40 bg-amber-400/15 text-amber-300'
                    : 'border-white/[0.1] bg-white/[0.04] text-slate-200 hover:bg-white/[0.1]'
                }`}
              >
                <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-amber-300 text-amber-300' : ''}`} />
                <span className="tabular-nums">{formatCompactNumber(game.likes)}</span>
              </button>
            </div>
          </div>

          <p className="mt-4 text-sm leading-relaxed text-slate-300">{game.description}</p>

          {/* Unboxed Feature List */}
          <div className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400">
            <span className="font-medium text-slate-300">Features:</span>
            {game.features.map((feat, idx) => (
              <span key={feat} className="inline-flex items-center gap-3">
                <span>{feat}</span>
                {idx < game.features.length - 1 && (
                  <span aria-hidden="true" className="text-slate-600">
                    /
                  </span>
                )}
              </span>
            ))}
          </div>

          {/* Live Metrics Strip */}
          <div className="mt-6 grid grid-cols-3 divide-x divide-white/[0.06] rounded-xl border border-white/[0.07] bg-[#080A0F] py-4 text-center">
            <div>
              <div className="font-mono text-lg font-bold text-[#4B83F2] tabular-nums">
                {formatCompactNumber(game.visits)}
              </div>
              <div className="mt-0.5 text-[11px] font-medium tracking-wider text-slate-400">
                TOTAL VISITS
              </div>
            </div>
            <div>
              <div className="font-mono text-lg font-bold text-[#34D399] tabular-nums">
                {game.playingNow.toLocaleString()}
              </div>
              <div className="mt-0.5 text-[11px] font-medium tracking-wider text-slate-400">
                PLAYING NOW
              </div>
            </div>
            <div>
              <div className="font-mono text-lg font-bold text-[#FBBF24] tabular-nums">
                {formatCompactNumber(game.likes)}
              </div>
              <div className="mt-0.5 text-[11px] font-medium tracking-wider text-slate-400">
                COMMUNITY LIKES
              </div>
            </div>
          </div>

          {/* Active Servers Table */}
          <div className="mt-7">
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-display text-base font-bold text-white">Active Server Instances</h3>
              <div className="flex items-center gap-3">
                {ALLOW_PUBLIC_EDITING && (
                  <button
                    type="button"
                    onClick={() => onEditWorld(game)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
                  >
                    <Pencil className="h-3 w-3" />
                    <span>Edit Join Links</span>
                  </button>
                )}
                <span className="text-xs text-slate-400 tabular-nums">
                  {game.servers.length} rooms open
                </span>
              </div>
            </div>

            <div className="mt-3 divide-y divide-white/[0.06] overflow-hidden rounded-xl border border-white/[0.07] bg-[#080A0F]">
              {game.servers.map((server: CondoServer) => {
                const isJoined = joinedServerId === server.id;
                const fillPct = Math.min(100, Math.round((server.players / server.maxPlayers) * 100));
                const isFull = server.players >= server.maxPlayers && !isJoined;
                const hasCustomLink = isSafeHttpUrl(server.joinUrl);

                return (
                  <div
                    key={server.id}
                    className="flex flex-col gap-3 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2.5">
                        <span className="font-medium text-sm text-white truncate">
                          {server.name}
                        </span>
                        <span className="text-xs text-slate-400">· {server.region}</span>
                      </div>
                      <div className="mt-1 flex items-center gap-3 text-xs text-slate-500 tabular-nums">
                        <span>{server.pingMs} ms ping</span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {server.players} / {server.maxPlayers} players
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      {/* Capacity Bar */}
                      <div className="hidden w-24 sm:block" aria-hidden="true">
                        <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.07]">
                          <div
                            className={`h-full rounded-full ${
                              fillPct > 85 ? 'bg-amber-400' : 'bg-emerald-400'
                            }`}
                            style={{ width: `${fillPct}%` }}
                          />
                        </div>
                      </div>

                      {hasCustomLink ? (
                        <a
                          href={server.joinUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => onJoinServer(game.id, server.id)}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-[#1E62EC] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                        >
                          <ExternalLink className="h-3 w-3" />
                          <span>Join Room</span>
                        </a>
                      ) : isJoined ? (
                        <button
                          type="button"
                          onClick={onLeaveServer}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/15 px-3.5 py-2 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/25 transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
                        >
                          <span>Connected · Leave</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={isFull}
                          onClick={() => onJoinServer(game.id, server.id)}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-[#1E62EC] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#2563EB] disabled:cursor-not-allowed disabled:opacity-45 transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                        >
                          <Play className="h-3 w-3 fill-current" />
                          <span>{isFull ? 'Server Full' : 'Join Room'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
