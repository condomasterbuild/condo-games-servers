import { ChangeEvent, DragEvent, FormEvent, useEffect, useRef, useState } from 'react';
import { Download, Plus, RotateCcw, Trash2, Upload, X } from 'lucide-react';
import {
  CondoCategory,
  CondoGame,
  CondoServer,
  DEFAULT_IMAGE_ADJUSTMENT,
  ImageAdjustment,
  INITIAL_CONDO_GAMES,
  isSafeHttpUrl,
} from '../data/condoGames';
import { CondoThumbnail } from './CondoThumbnail';

export interface WorldEditPayload {
  title: string;
  creator: string;
  category: CondoCategory;
  description: string;
  imageUrl: string | undefined;
  imageAdjustment: ImageAdjustment;
  servers: CondoServer[];
}

interface EditWorldModalProps {
  game: CondoGame | null;
  onClose: () => void;
  onSaveWorld: (gameId: string, payload: WorldEditPayload) => void;
  onDownloadPublishConfig: () => void;
}

const CATEGORIES: CondoCategory[] = ['Penthouse', 'Rooftop', 'Arcade', 'Chill & Scenic'];

function readAndCompressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Please select a valid image file (PNG, JPG, WebP, or GIF).'));
      return;
    }

    const isGif =
      file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the selected file.'));
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== 'string') {
        reject(new Error('Failed to load image data.'));
        return;
      }

      if (isGif) {
        resolve(result);
        return;
      }

      const img = new Image();
      img.onerror = () => reject(new Error('Invalid or corrupted image file.'));
      img.onload = () => {
        const maxWidth = 1280;
        const scale = img.width > maxWidth ? maxWidth / img.width : 1;
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));

        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(result);
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        try {
          const compressed = canvas.toDataURL('image/jpeg', 0.86);
          resolve(compressed);
        } catch {
          resolve(result);
        }
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  });
}

export function EditWorldModal({
  game,
  onClose,
  onSaveWorld,
  onDownloadPublishConfig,
}: EditWorldModalProps) {
  const [title, setTitle] = useState('');
  const [creator, setCreator] = useState('');
  const [category, setCategory] = useState<CondoCategory>('Penthouse');
  const [description, setDescription] = useState('');
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [adjustment, setAdjustment] = useState<ImageAdjustment>(DEFAULT_IMAGE_ADJUSTMENT);
  const [servers, setServers] = useState<CondoServer[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!game) return;
    setTitle(game.title);
    setCreator(game.creator);
    setCategory(game.category);
    setDescription(game.description);
    setImageUrlInput(game.imageUrl ?? '');
    setAdjustment(game.imageAdjustment ?? DEFAULT_IMAGE_ADJUSTMENT);
    setServers(game.servers.map((s) => ({ ...s })));
    setError('');
  }, [game]);

  useEffect(() => {
    if (!game) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [game, onClose]);

  if (!game) return null;

  const originalGame = INITIAL_CONDO_GAMES.find((g) => g.id === game.id);

  const processFile = async (file: File) => {
    setError('');
    setIsProcessing(true);
    try {
      const dataUrl = await readAndCompressImage(file);
      setImageUrlInput(dataUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load image.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void processFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      void processFile(file);
    }
  };

  const handleServerChange = (
    serverId: string,
    field: 'name' | 'region' | 'joinUrl',
    value: string
  ) => {
    setServers((prev) =>
      prev.map((srv) => (srv.id === serverId ? { ...srv, [field]: value } : srv))
    );
  };

  const handleAddServer = () => {
    const nextIndex = servers.length + 1;
    setServers((prev) => [
      ...prev,
      {
        id: `${game.id}-srv-${Date.now()}`,
        name: `Room 0${nextIndex}`,
        region: 'US East',
        pingMs: 28,
        players: 4,
        maxPlayers: game.maxPlayers,
        joinUrl: '',
      },
    ]);
  };

  const handleRemoveServer = (serverId: string) => {
    if (servers.length <= 1) return;
    setServers((prev) => prev.filter((s) => s.id !== serverId));
  };

  const handleRestoreOriginal = () => {
    if (originalGame) {
      setTitle(originalGame.title);
      setCreator(originalGame.creator);
      setCategory(originalGame.category);
      setDescription(originalGame.description);
      setImageUrlInput(originalGame.imageUrl ?? '');
      setServers(originalGame.servers.map((s) => ({ ...s })));
    } else {
      setImageUrlInput('');
    }
    setAdjustment(DEFAULT_IMAGE_ADJUSTMENT);
    setError('');
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedTitle = title.trim();
    const trimmedCreator = creator.trim();
    const trimmedDesc = description.trim();

    if (trimmedTitle.length < 2) {
      setError('Please enter a world title with at least 2 characters.');
      return;
    }
    if (trimmedCreator.length < 2) {
      setError('Please enter a creator or studio name.');
      return;
    }
    if (trimmedDesc.length < 5) {
      setError('Please enter a description (at least 5 characters).');
      return;
    }

    for (const srv of servers) {
      if (!srv.name.trim()) {
        setError('Every server room must have a name.');
        return;
      }
      if (srv.joinUrl && srv.joinUrl.trim().length > 0 && !isSafeHttpUrl(srv.joinUrl)) {
        setError(
          `Invalid Join Room link on "${srv.name}". Links must start with https:// or http://`
        );
        return;
      }
    }

    const cleanedUrl = imageUrlInput.trim();
    const cleanedServers = servers.map((srv) => ({
      ...srv,
      name: srv.name.trim(),
      region: srv.region.trim() || 'Global',
      joinUrl: srv.joinUrl?.trim() || undefined,
    }));

    onSaveWorld(game.id, {
      title: trimmedTitle,
      creator: trimmedCreator,
      category,
      description: trimmedDesc,
      imageUrl: cleanedUrl.length > 0 ? cleanedUrl : undefined,
      imageAdjustment: adjustment,
      servers: cleanedServers,
    });
    onClose();
  };

  const isDataUrl = imageUrlInput.startsWith('data:');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-world-title"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/[0.1] bg-[#0B0D13] p-6 shadow-2xl sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="edit-world-title" className="font-display text-xl font-bold text-white">
              Edit World Details, Links & Image
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Update title, description, thumbnail, and Join Room redirect links.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close world editor"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.04] text-slate-300 hover:bg-white/[0.1] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-5">
          {error && (
            <div
              role="alert"
              className="rounded-lg border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-xs text-red-300"
            >
              {error}
            </div>
          )}

          {/* Title & Description Section */}
          <div className="space-y-4">
            <div>
              <label htmlFor="edit-title" className="block text-xs font-medium text-slate-300">
                World Title
              </label>
              <input
                id="edit-title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter condo world title"
                className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="edit-creator" className="block text-xs font-medium text-slate-300">
                  Creator / Studio
                </label>
                <input
                  id="edit-creator"
                  type="text"
                  value={creator}
                  onChange={(e) => setCreator(e.target.value)}
                  className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div>
                <label htmlFor="edit-category" className="block text-xs font-medium text-slate-300">
                  Category
                </label>
                <select
                  id="edit-category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value as CondoCategory)}
                  className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="edit-description" className="block text-xs font-medium text-slate-300">
                Description
              </label>
              <textarea
                id="edit-description"
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe this condo world..."
                className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Join Room Links Section */}
          <div className="rounded-xl border border-white/[0.08] bg-[#06080D] p-4 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-semibold text-white">
                  Server Rooms &amp; Join Room Links
                </h3>
                <p className="mt-0.5 text-[11px] text-slate-400">
                  Visitors clicking Join Room will go directly to the URL you set here.
                </p>
              </div>
              <button
                type="button"
                onClick={handleAddServer}
                className="inline-flex items-center gap-1 rounded-lg border border-white/[0.1] bg-white/[0.05] px-2.5 py-1.5 text-xs font-medium text-slate-200 hover:bg-white/[0.1] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add Room</span>
              </button>
            </div>

            <div className="space-y-3">
              {servers.map((srv, idx) => (
                <div
                  key={srv.id}
                  className="rounded-lg border border-white/[0.07] bg-[#0B0D13] p-3 space-y-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[11px] font-medium text-slate-400">
                      Room 0{idx + 1}
                    </span>
                    {servers.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveServer(srv.id)}
                        aria-label={`Remove ${srv.name}`}
                        className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="h-3 w-3" />
                        <span>Remove</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    <input
                      type="text"
                      value={srv.name}
                      onChange={(e) => handleServerChange(srv.id, 'name', e.target.value)}
                      placeholder="Server name"
                      aria-label={`Server ${idx + 1} name`}
                      className="w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
                    />
                    <input
                      type="text"
                      value={srv.region}
                      onChange={(e) => handleServerChange(srv.id, 'region', e.target.value)}
                      placeholder="Region (e.g. US East)"
                      aria-label={`Server ${idx + 1} region`}
                      className="w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <input
                    type="url"
                    value={srv.joinUrl ?? ''}
                    onChange={(e) => handleServerChange(srv.id, 'joinUrl', e.target.value)}
                    placeholder="https://your-game-link.com/room"
                    aria-label={`Join Room URL for ${srv.name}`}
                    className="w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3 py-2 font-mono text-xs text-blue-300 placeholder:text-slate-600 focus:border-blue-500 focus:outline-none"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Live 16:9 Image Preview */}
          <div className="space-y-2">
            <span className="block text-xs font-medium text-slate-300">Thumbnail Preview</span>
            <div className="overflow-hidden rounded-xl border border-white/[0.08]">
              <CondoThumbnail
                title={title || game.title}
                imageUrl={imageUrlInput.trim() || undefined}
                sceneKey={game.sceneKey}
                adjustment={adjustment}
              />
            </div>
          </div>

          {/* Upload / Dropzone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`flex flex-col items-center justify-between gap-3 rounded-xl border border-dashed px-4 py-4 transition-colors sm:flex-row ${
              isDragging
                ? 'border-blue-500 bg-blue-500/10'
                : 'border-white/[0.12] bg-[#06080D]'
            }`}
          >
            <div className="text-center sm:text-left">
              <p className="text-xs font-medium text-slate-200">
                {isProcessing
                  ? 'Processing image...'
                  : 'Upload from device or drag and drop'}
              </p>
              <p className="mt-0.5 text-[11px] text-slate-500">
                PNG, JPG, WebP, or animated GIF · Static images resize automatically
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="inline-flex items-center gap-1.5 rounded-lg bg-white/[0.08] px-3.5 py-2 text-xs font-semibold text-white hover:bg-white/[0.14] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Choose File</span>
            </button>
          </div>

          {/* Image URL Input */}
          <div>
            <div className="flex items-center justify-between">
              <label htmlFor="edit-image-url" className="block text-xs font-medium text-slate-300">
                Image Path or URL
              </label>
              {imageUrlInput && (
                <button
                  type="button"
                  onClick={() => setImageUrlInput('')}
                  className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
                >
                  Use Architectural Fallback
                </button>
              )}
            </div>
            <input
              id="edit-image-url"
              type="text"
              value={isDataUrl ? '' : imageUrlInput}
              onChange={(e) => setImageUrlInput(e.target.value)}
              placeholder={
                isDataUrl
                  ? 'Custom uploaded image active (paste a URL here to replace)'
                  : 'https://... or /assets/my-condo.jpg'
              }
              className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          {/* Framing & Tone Adjustments */}
          <div className="rounded-xl border border-white/[0.07] bg-[#06080D] p-4 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200">Framing &amp; Tone</span>
              <button
                type="button"
                onClick={() => setAdjustment(DEFAULT_IMAGE_ADJUSTMENT)}
                className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
              >
                Reset Adjustments
              </button>
            </div>

            <div className="flex items-center justify-between gap-4">
              <span className="text-xs text-slate-400">Crop Alignment</span>
              <div className="flex items-center gap-1 rounded-lg border border-white/[0.06] bg-[#0B0D13] p-1">
                {(['top', 'center', 'bottom'] as const).map((pos) => (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => setAdjustment((prev) => ({ ...prev, objectPosition: pos }))}
                    className={`rounded-md px-3 py-1 text-xs font-medium capitalize transition-colors cursor-pointer ${
                      adjustment.objectPosition === pos
                        ? 'bg-[#1E62EC] text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {pos}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <label htmlFor="adj-brightness">Brightness</label>
                  <span className="font-mono tabular-nums">{adjustment.brightness}%</span>
                </div>
                <input
                  id="adj-brightness"
                  type="range"
                  min={60}
                  max={140}
                  value={adjustment.brightness}
                  onChange={(e) =>
                    setAdjustment((prev) => ({ ...prev, brightness: Number(e.target.value) }))
                  }
                  className="mt-1.5 w-full accent-blue-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <label htmlFor="adj-contrast">Contrast</label>
                  <span className="font-mono tabular-nums">{adjustment.contrast}%</span>
                </div>
                <input
                  id="adj-contrast"
                  type="range"
                  min={70}
                  max={140}
                  value={adjustment.contrast}
                  onChange={(e) =>
                    setAdjustment((prev) => ({ ...prev, contrast: Number(e.target.value) }))
                  }
                  className="mt-1.5 w-full accent-blue-500 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <label htmlFor="adj-saturate">Saturation</label>
                  <span className="font-mono tabular-nums">{adjustment.saturate}%</span>
                </div>
                <input
                  id="adj-saturate"
                  type="range"
                  min={40}
                  max={150}
                  value={adjustment.saturate}
                  onChange={(e) =>
                    setAdjustment((prev) => ({ ...prev, saturate: Number(e.target.value) }))
                  }
                  className="mt-1.5 w-full accent-blue-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.06] pt-4">
            <div className="flex flex-wrap items-center gap-2">
              {originalGame && (
                <button
                  type="button"
                  onClick={handleRestoreOriginal}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] px-3 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Restore Default</span>
                </button>
              )}

              <button
                type="button"
                onClick={onDownloadPublishConfig}
                title="Download src/data/condoGames.ts with your edits locked for free hosting"
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] px-3 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Export for Publish</span>
              </button>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-white/[0.08] px-4 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-[#1E62EC] px-5 py-2 text-xs font-semibold text-white hover:bg-[#2563EB] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                Save Changes
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
