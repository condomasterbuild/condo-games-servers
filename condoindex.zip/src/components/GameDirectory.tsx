import { RefObject } from 'react';
import { ArrowUpRight, Heart, Pencil, Search, X } from 'lucide-react';
import {
  ALLOW_PUBLIC_EDITING,
  CondoCategory,
  CondoGame,
  formatCompactNumber,
} from '../data/condoGames';
import { CondoThumbnail } from './CondoThumbnail';

export type FilterOption = 'All' | CondoCategory | 'Liked';
export type SortOption = 'playing' | 'likes' | 'visits' | 'newest';

interface GameDirectoryProps {
  games: CondoGame[];
  searchQuery: string;
  onSearchChange: (value: string) => void;
  activeFilter: FilterOption;
  onFilterChange: (filter: FilterOption) => void;
  sortBy: SortOption;
  onSortChange: (sort: SortOption) => void;
  likedIds: Set<string>;
  onToggleLike: (id: string) => void;
  onSelectGame: (game: CondoGame) => void;
  onEditWorld: (game: CondoGame) => void;
  searchInputRef: RefObject<HTMLInputElement | null>;
}

const FILTER_TABS: FilterOption[] = [
  'All',
  'Penthouse',
  'Rooftop',
  'Arcade',
  'Chill & Scenic',
  'Liked',
];

export function GameDirectory({
  games,
  searchQuery,
  onSearchChange,
  activeFilter,
  onFilterChange,
  sortBy,
  onSortChange,
  likedIds,
  onToggleLike,
  onSelectGame,
  onEditWorld,
  searchInputRef,
}: GameDirectoryProps) {
  const normalizedQuery = searchQuery.trim().toLowerCase();

  const filteredGames = games
    .filter((game) => {
      if (activeFilter === 'Liked') {
        if (!likedIds.has(game.id)) return false;
      } else if (activeFilter !== 'All' && game.category !== activeFilter) {
        return false;
      }

      if (!normalizedQuery) return true;
      return (
        game.title.toLowerCase().includes(normalizedQuery) ||
        game.creator.toLowerCase().includes(normalizedQuery) ||
        game.creatorHandle.toLowerCase().includes(normalizedQuery) ||
        game.category.toLowerCase().includes(normalizedQuery) ||
        game.description.toLowerCase().includes(normalizedQuery)
      );
    })
    .sort((a, b) => {
      if (sortBy === 'playing') return b.playingNow - a.playingNow;
      if (sortBy === 'likes') return b.likes - a.likes;
      if (sortBy === 'visits') return b.visits - a.visits;
      return b.updatedAt.localeCompare(a.updatedAt);
    });

  return (
    <section id="directory" className="mx-auto max-w-7xl px-6 py-16 lg:py-20">
      {/* Section Header */}
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Live Condo Directory
          </h2>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-slate-400">
            Filter active worlds by architecture style, check live server capacity, and leave a like
            to boost independent builders.
          </p>
        </div>

        {/* Search & Sort Controls */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative w-full sm:w-72">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search worlds or creators..."
              aria-label="Search condo worlds or creators"
              className="w-full rounded-lg border border-white/[0.08] bg-[#0B0D13] py-2.5 pl-10 pr-9 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                aria-label="Clear search"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value as SortOption)}
            aria-label="Sort condo games"
            className="rounded-lg border border-white/[0.08] bg-[#0B0D13] px-3.5 py-2.5 text-sm font-medium text-slate-200 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 cursor-pointer"
          >
            <option value="playing">Sort: Playing Now</option>
            <option value="likes">Sort: Most Liked</option>
            <option value="visits">Sort: Total Visits</option>
            <option value="newest">Sort: Recently Updated</option>
          </select>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4 border-b border-white/[0.06] pb-5">
        <div
          className="flex flex-wrap items-center gap-1.5 rounded-lg bg-[#0B0D13] p-1 border border-white/[0.06]"
          role="tablist"
          aria-label="Condo categories"
        >
          {FILTER_TABS.map((tab) => {
            const active = activeFilter === tab;
            return (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => onFilterChange(tab)}
                className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  active
                    ? 'bg-[#1E62EC] text-white'
                    : 'text-slate-400 hover:bg-white/[0.05] hover:text-slate-200'
                }`}
              >
                {tab === 'Liked' ? `Liked (${likedIds.size})` : tab}
              </button>
            );
          })}
        </div>

        <p className="text-xs text-slate-500 tabular-nums">
          Showing {filteredGames.length} of {games.length} live worlds
        </p>
      </div>

      {/* Directory Grid */}
      {filteredGames.length === 0 ? (
        <div className="mt-10 rounded-xl border border-white/[0.06] bg-[#0B0D13] px-6 py-16 text-center">
          <p className="font-display text-lg font-semibold text-white">No condo worlds match your filters</p>
          <p className="mt-1.5 text-sm text-slate-400">
            Try clearing your search query or switching back to all categories.
          </p>
          <button
            type="button"
            onClick={() => {
              onSearchChange('');
              onFilterChange('All');
            }}
            className="mt-5 rounded-lg bg-white/[0.08] px-4 py-2 text-xs font-semibold text-white hover:bg-white/[0.14] transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredGames.map((game) => {
            const isLiked = likedIds.has(game.id);
            return (
              <article
                key={game.id}
                className="group flex flex-col overflow-hidden rounded-xl border border-white/[0.07] bg-[#0B0D13] transition-colors duration-150 hover:border-white/[0.16]"
              >
                {/* Clickable Media */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => onSelectGame(game)}
                    className="relative block w-full text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                  >
                    <CondoThumbnail
                      title={game.title}
                      imageUrl={game.imageUrl}
                      sceneKey={game.sceneKey}
                      adjustment={game.imageAdjustment}
                    />
                  </button>
                  {ALLOW_PUBLIC_EDITING && (
                    <button
                      type="button"
                      onClick={() => onEditWorld(game)}
                      aria-label={`Edit ${game.title}`}
                      className="absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-lg border border-white/[0.14] bg-black/70 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 backdrop-blur-sm opacity-90 sm:opacity-0 sm:group-hover:opacity-100 focus-visible:opacity-100 hover:bg-black hover:text-white transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
                    >
                      <Pencil className="h-3 w-3" />
                      <span>Edit</span>
                    </button>
                  )}
                </div>

                {/* Card Content */}
                <div className="flex flex-1 flex-col p-5">
                  {/* Unboxed Metadata Line (Zero-Pill Discipline) */}
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <span className="font-medium text-slate-300">{game.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="truncate">by {game.creator}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums shrink-0">{game.maxPlayers} max</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectGame(game)}
                    className="mt-2 text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
                  >
                    <h3 className="font-display text-lg font-bold tracking-tight text-white group-hover:text-blue-400 transition-colors">
                      {game.title}
                    </h3>
                  </button>

                  <p className="mt-1.5 line-clamp-2 text-sm leading-relaxed text-slate-400">
                    {game.description}
                  </p>

                  {/* Metrics Row */}
                  <div className="mt-5 grid grid-cols-3 border-t border-white/[0.06] pt-4 text-left">
                    <div>
                      <div className="font-mono text-sm font-semibold text-[#34D399] tabular-nums">
                        {formatCompactNumber(game.playingNow)}
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">Playing</div>
                    </div>
                    <div>
                      <div className="font-mono text-sm font-semibold text-[#4B83F2] tabular-nums">
                        {formatCompactNumber(game.visits)}
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">Visits</div>
                    </div>
                    <div>
                      <div className="font-mono text-sm font-semibold text-[#FBBF24] tabular-nums">
                        {formatCompactNumber(game.likes)}
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">Likes</div>
                    </div>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="mt-5 flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => onSelectGame(game)}
                      className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[#1E62EC] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#2563EB] transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
                    >
                      <span>View Servers</span>
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onToggleLike(game.id)}
                      aria-pressed={isLiked}
                      aria-label={isLiked ? `Unlike ${game.title}` : `Like ${game.title}`}
                      className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3.5 py-2.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                        isLiked
                          ? 'border-amber-400/40 bg-amber-400/10 text-amber-300'
                          : 'border-white/[0.08] bg-white/[0.03] text-slate-300 hover:bg-white/[0.08] hover:text-white'
                      }`}
                    >
                      <Heart className={`h-3.5 w-3.5 ${isLiked ? 'fill-amber-300 text-amber-300' : ''}`} />
                      <span>{isLiked ? 'Liked' : 'Like'}</span>
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
