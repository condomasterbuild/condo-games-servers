import { ChangeEvent, DragEvent, FormEvent, useEffect, useRef, useState } from 'react';
import { RotateCcw, Upload, X } from 'lucide-react';

export type GradientPresetId =
  | 'obsidian-cobalt'
  | 'midnight-indigo'
  | 'emerald-abyss'
  | 'amber-dusk';

export interface BackgroundSettings {
  mode: 'solid' | 'gradient' | 'image';
  solidColor: string;
  gradientPreset: GradientPresetId;
  imageUrl: string;
  overlayOpacity: number;
  blurPx: number;
  scope: 'hero' | 'page';
}

export const DEFAULT_BACKGROUND_SETTINGS: BackgroundSettings = {
  mode: 'solid',
  solidColor: '#050608',
  gradientPreset: 'obsidian-cobalt',
  imageUrl: '',
  overlayOpacity: 65,
  blurPx: 0,
  scope: 'hero',
};

export const GRADIENT_PRESETS: Record<
  GradientPresetId,
  { label: string; css: string }
> = {
  'obsidian-cobalt': {
    label: 'Obsidian Cobalt',
    css: 'radial-gradient(ellipse 80% 60% at 65% 0%, rgba(30, 98, 236, 0.22), transparent 65%), #050608',
  },
  'midnight-indigo': {
    label: 'Midnight Slate',
    css: 'linear-gradient(145deg, #0b1326 0%, #060913 55%, #050608 100%)',
  },
  'emerald-abyss': {
    label: 'Emerald Dusk',
    css: 'radial-gradient(ellipse 75% 55% at 30% 10%, rgba(16, 185, 129, 0.16), transparent 65%), #050608',
  },
  'amber-dusk': {
    label: 'Warm Penthouse',
    css: 'radial-gradient(ellipse 70% 55% at 75% 15%, rgba(245, 158, 11, 0.14), transparent 65%), #050608',
  },
};

interface EditBackgroundModalProps {
  isOpen: boolean;
  settings: BackgroundSettings;
  onClose: () => void;
  onSave: (next: BackgroundSettings) => void;
}

function readAndCompressBackground(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('Please select a valid image file (PNG, JPG, WebP, or GIF).'));
      return;
    }

    const isGif =
      file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the selected file.'));
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== 'string') {
        reject(new Error('Failed to load image data.'));
        return;
      }

      if (isGif) {
        resolve(result);
        return;
      }

      const img = new Image();
      img.onerror = () => reject(new Error('Invalid or corrupted image file.'));
      img.onload = () => {
        const maxWidth = 1600;
        const scale = img.width > maxWidth ? maxWidth / img.width : 1;
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));

        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(result);
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        try {
          resolve(canvas.toDataURL('image/jpeg', 0.84));
        } catch {
          resolve(result);
        }
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  });
}

export function EditBackgroundModal({
  isOpen,
  settings,
  onClose,
  onSave,
}: EditBackgroundModalProps) {
  const [draft, setDraft] = useState<BackgroundSettings>(settings);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setDraft(settings);
    setError('');
  }, [isOpen, settings]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const processFile = async (file: File) => {
    setError('');
    setIsProcessing(true);
    try {
      const dataUrl = await readAndCompressBackground(file);
      setDraft((prev) => ({
        ...prev,
        mode: 'image',
        imageUrl: dataUrl,
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load background image.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void processFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      void processFile(file);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (draft.mode === 'image' && !draft.imageUrl.trim()) {
      setError('Please upload a background image or paste an image URL.');
      return;
    }
    onSave(draft);
    onClose();
  };

  const handleReset = () => {
    setDraft(DEFAULT_BACKGROUND_SETTINGS);
    onSave(DEFAULT_BACKGROUND_SETTINGS);
    onClose();
  };

  const isDataUrl = draft.imageUrl.startsWith('data:');

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-bg-title"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl border border-white/[0.1] bg-[#0B0D13] p-6 shadow-2xl sm:p-7"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="edit-bg-title" className="font-display text-xl font-bold text-white">
              Customize Background
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Choose a solid color, atmospheric gradient, or upload your own backdrop image.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close background editor"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.04] text-slate-300 hover:bg-white/[0.1] hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-6 space-y-5">
          {/* Live Preview */}
          <div className="relative h-36 w-full overflow-hidden rounded-xl border border-white/[0.08] bg-[#050608]">
            {draft.mode === 'solid' && (
              <div
                className="absolute inset-0"
                style={{ backgroundColor: draft.solidColor }}
              />
            )}
            {draft.mode === 'gradient' && (
              <div
                className="absolute inset-0"
                style={{ background: GRADIENT_PRESETS[draft.gradientPreset].css }}
              />
            )}
            {draft.mode === 'image' && draft.imageUrl && (
              <>
                <img
                  src={draft.imageUrl}
                  alt="Background preview"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 h-full w-full object-cover"
                  style={{
                    filter: draft.blurPx > 0 ? `blur(${draft.blurPx}px)` : undefined,
                    transform: draft.blurPx > 0 ? 'scale(1.06)' : undefined,
                  }}
                />
                <div
                  className="absolute inset-0 bg-[#050608]"
                  style={{ opacity: draft.overlayOpacity / 100 }}
                />
              </>
            )}

            <div className="relative flex h-full flex-col justify-center px-6">
              <p className="font-display text-lg font-extrabold leading-tight text-white">
                Find Your Perfect Condo, Faster.
              </p>
              <p className="mt-1 text-xs text-slate-300">
                Live background legibility preview
              </p>
            </div>
          </div>

          {error && (
            <div
              role="alert"
              className="rounded-lg border border-red-500/30 bg-red-500/10 px-3.5 py-2.5 text-xs text-red-300"
            >
              {error}
            </div>
          )}

          {/* Mode Selector */}
          <div>
            <span className="block text-xs font-medium text-slate-300">Background Type</span>
            <div className="mt-2 grid grid-cols-3 gap-1.5 rounded-lg border border-white/[0.06] bg-[#06080D] p-1">
              {(
                [
                  { id: 'solid', label: 'Solid Color' },
                  { id: 'gradient', label: 'Gradient' },
                  { id: 'image', label: 'Custom Image' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setError('');
                    setDraft((prev) => ({ ...prev, mode: tab.id }));
                  }}
                  className={`rounded-md px-3 py-2 text-xs font-medium transition-colors cursor-pointer ${
                    draft.mode === tab.id
                      ? 'bg-[#1E62EC] text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Solid Color Controls */}
          {draft.mode === 'solid' && (
            <div className="rounded-xl border border-white/[0.07] bg-[#06080D] p-4 space-y-3">
              <div className="flex items-center justify-between">
                <label htmlFor="bg-solid-color" className="text-xs font-medium text-slate-300">
                  Color Swatch
                </label>
                <span className="font-mono text-xs text-slate-400 uppercase">
                  {draft.solidColor}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2.5">
                {['#050608', '#090D16', '#0A101F', '#0D1117', '#081412', '#120C18'].map(
                  (hex) => (
                    <button
                      key={hex}
                      type="button"
                      onClick={() => setDraft((prev) => ({ ...prev, solidColor: hex }))}
                      aria-label={`Select color ${hex}`}
                      className={`h-8 w-8 rounded-lg border transition-transform cursor-pointer ${
                        draft.solidColor.toLowerCase() === hex.toLowerCase()
                          ? 'scale-110 border-blue-400 ring-2 ring-blue-500/40'
                          : 'border-white/[0.14]'
                      }`}
                      style={{ backgroundColor: hex }}
                    />
                  )
                )}
                <input
                  id="bg-solid-color"
                  type="color"
                  value={draft.solidColor}
                  onChange={(e) =>
                    setDraft((prev) => ({ ...prev, solidColor: e.target.value }))
                  }
                  className="h-8 w-12 cursor-pointer rounded-lg border border-white/[0.14] bg-transparent p-0.5"
                />
              </div>
            </div>
          )}

          {/* Gradient Presets */}
          {draft.mode === 'gradient' && (
            <div className="grid grid-cols-2 gap-2.5">
              {(Object.keys(GRADIENT_PRESETS) as GradientPresetId[]).map((key) => {
                const preset = GRADIENT_PRESETS[key];
                const active = draft.gradientPreset === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setDraft((prev) => ({ ...prev, gradientPreset: key }))}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-colors cursor-pointer ${
                      active
                        ? 'border-blue-500 bg-blue-500/10'
                        : 'border-white/[0.08] bg-[#06080D] hover:border-white/[0.18]'
                    }`}
                  >
                    <span
                      className="h-8 w-8 shrink-0 rounded-lg border border-white/[0.12]"
                      style={{ background: preset.css }}
                    />
                    <span className="text-xs font-medium text-white">{preset.label}</span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Custom Image Controls */}
          {draft.mode === 'image' && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`flex flex-col items-center justify-between gap-3 rounded-xl border border-dashed px-4 py-4 transition-colors sm:flex-row ${
                  isDragging
                    ? 'border-blue-500 bg-blue-500/10'
                    : 'border-white/[0.12] bg-[#06080D]'
                }`}
              >
                <div className="text-center sm:text-left">
                  <p className="text-xs font-medium text-slate-200">
                    {isProcessing
                      ? 'Processing backdrop...'
                      : 'Upload a backdrop image or drag and drop'}
                  </p>
                  <p className="mt-0.5 text-[11px] text-slate-500">
                    PNG, JPG, WebP, or animated GIF · Saved locally in your browser
                  </p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessing}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-white/[0.08] px-3.5 py-2 text-xs font-semibold text-white hover:bg-white/[0.14] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="h-3.5 w-3.5" />
                  <span>Choose File</span>
                </button>
              </div>

              <div>
                <label htmlFor="bg-image-url" className="block text-xs font-medium text-slate-300">
                  Or Paste Image URL
                </label>
                <input
                  id="bg-image-url"
                  type="text"
                  value={isDataUrl ? '' : draft.imageUrl}
                  onChange={(e) =>
                    setDraft((prev) => ({ ...prev, imageUrl: e.target.value }))
                  }
                  placeholder={
                    isDataUrl
                      ? 'Custom uploaded backdrop active (paste URL to replace)'
                      : 'https://... or /src/assets/images/...'
                  }
                  className="mt-1.5 w-full rounded-lg border border-white/[0.08] bg-[#06080D] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 gap-4 rounded-xl border border-white/[0.07] bg-[#06080D] p-4 sm:grid-cols-2">
                <div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <label htmlFor="bg-overlay">Dark Tint</label>
                    <span className="font-mono tabular-nums">{draft.overlayOpacity}%</span>
                  </div>
                  <input
                    id="bg-overlay"
                    type="range"
                    min={15}
                    max={95}
                    value={draft.overlayOpacity}
                    onChange={(e) =>
                      setDraft((prev) => ({
                        ...prev,
                        overlayOpacity: Number(e.target.value),
                      }))
                    }
                    className="mt-1.5 w-full accent-blue-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <label htmlFor="bg-blur">Backdrop Blur</label>
                    <span className="font-mono tabular-nums">{draft.blurPx}px</span>
                  </div>
                  <input
                    id="bg-blur"
                    type="range"
                    min={0}
                    max={24}
                    value={draft.blurPx}
                    onChange={(e) =>
                      setDraft((prev) => ({ ...prev, blurPx: Number(e.target.value) }))
                    }
                    className="mt-1.5 w-full accent-blue-500 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Apply Scope */}
          <div className="flex items-center justify-between gap-4 rounded-xl border border-white/[0.07] bg-[#06080D] px-4 py-3">
            <span className="text-xs font-medium text-slate-300">Apply Background To</span>
            <div className="flex items-center gap-1 rounded-lg border border-white/[0.06] bg-[#0B0D13] p-1">
              {(
                [
                  { id: 'hero', label: 'Hero Only' },
                  { id: 'page', label: 'Full Page' },
                ] as const
              ).map((option) => (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setDraft((prev) => ({ ...prev, scope: option.id }))}
                  className={`rounded-md px-3 py-1 text-xs font-medium transition-colors cursor-pointer ${
                    draft.scope === option.id
                      ? 'bg-[#1E62EC] text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset Default</span>
            </button>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-white/[0.08] px-4 py-2 text-xs font-medium text-slate-300 hover:bg-white/[0.06] hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-[#1E62EC] px-5 py-2 text-xs font-semibold text-white hover:bg-[#2563EB] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                Apply Background
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
